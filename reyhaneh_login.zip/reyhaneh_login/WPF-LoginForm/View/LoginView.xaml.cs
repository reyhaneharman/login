﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;
using System.Windows.Media;
using System.Windows.Media.Effects;

namespace WPF_LoginForm.View
{
    /// <summary>
    /// Interaction logic for LoginView.xaml
    /// </summary>
    public partial class LoginView : Window
    {
        public LoginView()
        {
            InitializeComponent();
            DispatcherTimer timer = new DispatcherTimer();
            Random random = new Random();
            timer.Interval = TimeSpan.FromMilliseconds(300);
            timer.Tick += (s, e) =>
            {
                byte r = (byte)random.Next(256);
                byte g = (byte)random.Next(256);
                byte b = (byte)random.Next(256);
                mytext.Foreground = new
                SolidColorBrush(Color.FromRgb(r, g, b));
            };
            timer.Start();
        }

        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
                DragMove();
        }

        private void btnMinimize_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        }

        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            bool allfilled = true;

            if

                (string.IsNullOrEmpty(txtUser.Text))
            {
                txtUser.BorderBrush = Brushes.Red;
                allfilled = false;

            }
            else
            {
                txtUser.ClearValue(BorderBrushProperty); 
            }
            if
                (string.IsNullOrEmpty(txtPass.Password))
            {
                txtPass.BorderBrush = Brushes.Red;
                allfilled = false;
            }
            else
            {
                txtPass.ClearValue(BorderBrushProperty);
            }
            if (allfilled)
            {
                resume resume = new resume();
                resume.Show();
            }
        }
         
          
        

        private void btnhelp_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("warning",
                "Please enter your information correctly and avoid leaving username and password blank.", MessageBoxButton.OK
             ,MessageBoxImage.Warning);
        }


        private void myimage_mouseenter(object sender, MouseEventArgs e)

        {
            ((ScaleTransform)myimage.RenderTransform).ScaleX = 1.3;
            ((ScaleTransform)myimage.RenderTransform).ScaleY = 1.3;


            ((DropShadowEffect)myimage.Effect).BlurRadius = 10;

        }
        private void myimage_MouseLeave(object sender, MouseEventArgs e)
        {
            ((ScaleTransform)myimage.RenderTransform).ScaleX = 1;
            ((ScaleTransform)myimage.RenderTransform).ScaleY = 1;
            ((DropShadowEffect)myimage.Effect).BlurRadius = 0;

        }

        private void txtUser_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
