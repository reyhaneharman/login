﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Forms;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Drawing;
using Microsoft.Win32;
using System.IO;
using drawingcolor = System.Drawing.Color;
using System.Runtime.InteropServices.ComTypes;
namespace WPF_LoginForm
{
    /// <summary>
    /// Interaction logic for resume.xaml
    /// </summary>
    public partial class resume : Window, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        private string _firstname;
        private string _jobhistory;
        private string _degreelevel;
        private DateTime? _age;

      
        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public string firstname
        {
           get=> _firstname;
            set{ _firstname = value; OnPropertyChanged(nameof(ContractPreview));}
         
        }
      
     
        public string jobhistory
        {
            get => _jobhistory;
            set { _jobhistory = value; OnPropertyChanged(nameof(ContractPreview)); }
        }

        public string degreelevel
        {
            get => _degreelevel;
            set { _degreelevel = value; OnPropertyChanged(nameof(ContractPreview)); }
        }
        public DateTime? age

        {
            get => _age;
            set { _age = value; OnPropertyChanged(nameof(ContractPreview)); }
        }
        public string ContractPreview =>
                        "hi how are you?\n" + "\n\n" +
            $"-  my name is: {(string.IsNullOrWhiteSpace(firstname) ? "........" : firstname)} " +
             $"and my work hisrory is like this {(string.IsNullOrWhiteSpace(jobhistory) ? "........" : jobhistory)} .\n" +
              "- i have a degreelevel in: " +
            $"{(string.IsNullOrWhiteSpace(degreelevel) ? "........" : degreelevel)}\n" +
        "- oh,sorry,i forgot my age: " +
        $"{(age.HasValue ? age.Value.ToString("MMMM dd, yyyy") : "........")}\n \n" + $"_Additional description:";








        public resume()
        {
            InitializeComponent();
            DataContext = this;
               
        }

        private void color_click(object sender, RoutedEventArgs e)
        {
            var colordialog = new ColorDialog();
            if(colordialog.ShowDialog()==System.Windows.Forms.DialogResult.OK)
            {
                System.Drawing.Color
                    selectedcolor = colordialog.Color;
               txtblock.Foreground = new SolidColorBrush(System.Windows.Media.Color.FromArgb(selectedcolor.A, selectedcolor.R, selectedcolor.G,
                   selectedcolor.B));
                textblok1.Foreground = new SolidColorBrush(System.Windows.Media.Color.FromArgb(selectedcolor.A, selectedcolor.R, selectedcolor.G,
                  selectedcolor.B));
            }
        }

        private void upload_Click(object sender, RoutedEventArgs e)
        {
          Microsoft.Win32.OpenFileDialog openFileDialog = new Microsoft.Win32.OpenFileDialog();
            openFileDialog.Title = "یک فایل انتخاب کنید";
            openFileDialog.Filter = "text files(*.txt)|*.txt|All files(*.*)|*.*";
            if(openFileDialog.ShowDialog()==true)
            {
                string filecontent=File.ReadAllText(openFileDialog.FileName);
                txtblock.Text = filecontent;
            }

        }

        private void font_click(object sender, RoutedEventArgs e)
        {
            using (FontDialog fontDialog = new FontDialog())
            {
                if (fontDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK) { 
                var selectedfont=fontDialog.Font;
                    txtblock.FontFamily = new
                        System.Windows.Media.FontFamily(selectedfont. Name);
                    txtblock.FontSize = selectedfont.Size * 96.0 / 72.0;
                    textblok1.FontSize = selectedfont.Size * 96.0 / 72.0;
                }
            }
        }

        private void onSaveFileClicked(object sender, RoutedEventArgs e)
        {
            var dlg=new
      Microsoft.Win32.SaveFileDialog();
            dlg.Filter= "text files(*.txt)|*.txt|All files(*.*)|*.*";
            bool? result = dlg.ShowDialog();
            if (result == true)
            {

                string filename = dlg.FileName;

                string content = textblok1.Text + txtblock.Text;
                System.IO.File.WriteAllText(filename, content);

            }
        }

        private void onDeleteFileClicked(object sender, RoutedEventArgs e)
        {
            txtblock.Text = "";
        }

        private void onLoadFileClicked(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.OpenFileDialog openFileDialog = new Microsoft.Win32.OpenFileDialog();
            openFileDialog.Title = "یک فایل انتخاب کنید";
            openFileDialog.Filter = "text files(*.txt)|*.txt|All files(*.*)|*.*";
            if (openFileDialog.ShowDialog() == true)
            {
                string filecontent = File.ReadAllText(openFileDialog.FileName);
                txtblock.Text = filecontent;
            }
        }
        private void textbox_name(object sender, TextChangedEventArgs e)
        {

        }
        private void textbox_jobhistory(object sender, TextChangedEventArgs e)
        {

        }
        private void textbox_degreelevel(object sender, TextChangedEventArgs e)
        {

        }
        private void datapiker_age_selecteddatachenged(object sender, SelectionChangedEventArgs e)
        {

        }
      

        private void ClearEmployeeSignature(object sender, RoutedEventArgs e)
        {
            ColorDialog colorDialog = new ColorDialog();
            if(colorDialog.ShowDialog()==System.Windows.Forms.DialogResult.OK)
            {
                System.Drawing.Color 
                    selectedcolor=colorDialog.Color;
                System.Windows.Media.Color
                    wpfcolor=System.Windows.Media.Color.FromArgb (selectedcolor.A, selectedcolor.R, selectedcolor.G, selectedcolor.B);
                EmployeeSignatureCanvas.DefaultDrawingAttributes.Color = wpfcolor;
            }

            ColorDialog colorDialog1 = new ColorDialog();
            if (colorDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                System.Drawing.Color
                    selectedcolor = colorDialog.Color;
                System.Windows.Media.Color
                    wpfcolor = System.Windows.Media.Color.FromArgb(selectedcolor.A, selectedcolor.R, selectedcolor.G, selectedcolor.B);
                EmployerSignatureCanvas.DefaultDrawingAttributes.Color = wpfcolor;
            }
        }

        private void ClearEmployerSignature(object sender, RoutedEventArgs e)
        {
            EmployerSignatureCanvas.Strokes.Clear();
            EmployeeSignatureCanvas.Strokes.Clear();

        }

        private void PrintContract(object sender, RoutedEventArgs e)
        {
            bool allfil = true;
            if (string.IsNullOrEmpty(first.Text))
            {
                first.BorderBrush = System.Windows.Media.Brushes.Red;
                allfil = false;
            }
            else
            {
                first.ClearValue(BorderBrushProperty);
            }

            if (string.IsNullOrEmpty(history.Text))
            {
                history.BorderBrush = System.Windows.Media.Brushes.Red;
                allfil = false;
            }
            else
            {
                history.ClearValue(BorderBrushProperty);
            }

            if (string.IsNullOrEmpty(degree.Text))
            {

                degree.BorderBrush = System.Windows.Media.Brushes.Red;
                allfil = false;
            }
            else
            {
                degree.ClearValue(BorderBrushProperty);
            }
            if (allfil)
            {
                System.Windows.Controls.PrintDialog printDialog = new
                    System.Windows.Controls.PrintDialog();
                if (printDialog.ShowDialog() == true)
                {
                    printDialog.PrintVisual(printarea, "چاپ قررداد");
                }
            }
        }
        private void color1_click(object sender, RoutedEventArgs e)
        {
            var colordialog = new ColorDialog();
            if (colordialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                System.Drawing.Color
                    selectedcolor = colordialog.Color;
                txtblock.Foreground = new SolidColorBrush(System.Windows.Media.Color.FromArgb(selectedcolor.A, selectedcolor.R, selectedcolor.G,
                    selectedcolor.B));
                textblok1.Foreground = new SolidColorBrush(System.Windows.Media.Color.FromArgb(selectedcolor.A, selectedcolor.R, selectedcolor.G,
                  selectedcolor.B));
            }
        }
        private void font1_click(object sender, RoutedEventArgs e)
        {
            using (FontDialog fontDialog = new FontDialog())
            {
                if (fontDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    var selectedfont = fontDialog.Font;
                    txtblock.FontFamily = new
                        System.Windows.Media.FontFamily(selectedfont.Name);
                    txtblock.FontSize = selectedfont.Size * 96.0 / 72.0;
                    textblok1.FontSize = selectedfont.Size * 96.0 / 72.0;

                }
            }
        }
            private void exit_click(object sender, RoutedEventArgs e)
        {
          this.Close();  
        }

        }
    }

